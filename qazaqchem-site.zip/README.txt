QazaqChem: статический сайт, главный файл index.html.

1) Загрузите папку на GitHub и включите GitHub Pages (Settings > Pages > Deploy from a branch > main / root).
2) ИИ внутри Claude работает сам. На GitHub Pages нужен прокси: gemini-worker/worker.js (Cloudflare Worker).
   - Создайте Worker, вставьте worker.js
   - Settings > Variables: секрет GEMINI_API_KEY (ключ из Google AI Studio), ALLOWED_ORIGIN = адрес вашего сайта
   - Скопируйте адрес Worker в index.html, строка const AI_URL=''
Ключ Gemini не вставляйте в index.html: его увидят все.
