// Cloudflare Worker: прокси между сайтом и Gemini API.
// Ключ хранится как секрет GEMINI_API_KEY, в браузер не попадает.
// Переменные: ALLOWED_ORIGIN (например https://username.github.io), GEMINI_MODEL (необязательно).
export default {
  async fetch(req, env) {
    const cors = {
      'Access-Control-Allow-Origin': env.ALLOWED_ORIGIN || '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };
    const json = (obj, status = 200) =>
      new Response(JSON.stringify(obj), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (req.method !== 'POST') return json({ error: 'method' }, 405);

    let body;
    try { body = await req.json(); } catch { return json({ error: 'bad_json' }, 400); }
    const input = Array.isArray(body.input) ? body.input.slice(-12) : [];
    if (!input.length) return json({ error: 'empty' }, 400);

    const contents = input.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(m.content).slice(0, 4000) }],
    }));
    const model = env.GEMINI_MODEL || 'gemini-2.5-flash';

    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
      body: JSON.stringify({ contents, generationConfig: { maxOutputTokens: 800, temperature: 0.4 } }),
    });
    if (!r.ok) return json({ error: 'upstream' }, r.status === 429 ? 429 : 502);

    const j = await r.json();
    const text = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
    return json({ text });
  },
};
